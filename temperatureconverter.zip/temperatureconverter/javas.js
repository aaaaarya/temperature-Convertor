// const checkbox = document.getElementById("checkbox")
// checkbox.addEventListener("change", () => {
//     document.body.classList.toggle("dark")
// })
const celsiusInput = document.querySelector('#celsiusInput'); // commonly used for accessing and manipulating elements on a web page.
const fahrenheitInput = document.querySelector('#fahrenheitInput');
const kelvinInput = document.querySelector('#kelvinInput');
const resetButton = document.querySelector('.reset-button');

function roundNumber(number) {
    return Math.round(number * 100) / 100; //round the no to the nearest integer
}

/* Celsius to Fahrenheit and Kelvin */
celsiusInput.addEventListener('input', function () {
    const cTemp = parseFloat(celsiusInput.value);
    const fTemp = (cTemp * (9 / 5)) + 32;
    const kTemp = cTemp + 273.15;

    fahrenheitInput.value = roundNumber(fTemp);
    kelvinInput.value = roundNumber(kTemp);
});

/* Fahrenheit to Celsius and Kelvin */
fahrenheitInput.addEventListener('input', function () {
    const fTemp = parseFloat(fahrenheitInput.value);
    const cTemp = (fTemp - 32) * (5 / 9);
    const kTemp = (fTemp - 32) * (5 / 9) + 273.15;

    celsiusInput.value = roundNumber(cTemp);
    kelvinInput.value = roundNumber(kTemp);
});

/* Kelvin to Celsius and Fahrenheit */
kelvinInput.addEventListener('input', function () {
    const kTemp = parseFloat(kelvinInput.value);
    const cTemp = kTemp - 273.15;
    const fTemp = (kTemp - 273.15) * (9 / 5) + 32;

    celsiusInput.value = roundNumber(cTemp);
    fahrenheitInput.value = roundNumber(fTemp);
});

resetButton.addEventListener('click', () => {
    celsiusInput.value = '';
    fahrenheitInput.value = '';
    kelvinInput.value = '';
});

